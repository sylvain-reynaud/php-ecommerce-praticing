<ul>
    <li><a href="index.php?action=update&controller=ControllerUtilisateur">Modifier mon compte</a></li>
    <li><a href="index.php?action=readAllOfUser&controller=ControllerCommande">Voir mes commandes</a></li>
</ul>
