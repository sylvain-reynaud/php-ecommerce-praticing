<div class="card-panel teal lighten-2">
    <h1>Error</h1>
    <h2>This page does not exist</h2>
    <h2>Détails : <?php echo $error ?></h2>
</div>